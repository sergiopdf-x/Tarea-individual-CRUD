import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);
    static ArrayList<Persona> personas = new ArrayList<>();
    public static void main(String[] args) {
        int opcion = 0;
        do {
            System.out.println("----------- MENU ------------");
            System.out.println("1. Registrar persona");
            System.out.println("2. Mostrar registros");
            System.out.println("3. Actualizar registro");
            System.out.println("4. Eliminar registro");
            System.out.println("5. Salir");
            System.out.print("Ingrese una opcion: ");

            try {
                opcion = Integer.parseInt(sc.nextLine());
                switch(opcion){
                    case 1:
                        registrar();
                        break;
                    case 2:
                        mostrar();
                        break;
                    case 3:
                        actualizar();
                        break;
                    case 4:
                        eliminar();
                        break;
                    case 5:
                        System.out.println("Programa finalizado");
                        break;
                    default:
                        System.out.println("Error: opcion invalida");
                }
            }catch(NumberFormatException e){
                System.out.println("Debe ingresar solo numeros");
            }
        }while(opcion != 5);
    }

    public static void registrar(){
        try{
            System.out.println("\nSeleccione tipo:");
            System.out.println("1. Estudiante");
            System.out.println("2. Docente");
            System.out.print("Opcion: ");

            int tipo = Integer.parseInt(sc.nextLine());
            System.out.print("Cedula: ");
            String cedula = sc.nextLine().trim();
            if(cedula.isEmpty()){
                System.out.println("Campo obligatorio");
                return;
            }
            for(Persona p : personas){
                if(p.getCedula().equals(cedula)){
                    System.out.println("Cedula ya registrada");
                    return;
                }
            }
            System.out.print("Nombre completo: ");
            String nombre = sc.nextLine().trim();

            if(nombre.isEmpty()){
                System.out.println("Campo obligatorio");
                return;
            }
            System.out.print("Edad: ");
            int edad = Integer.parseInt(sc.nextLine());

            if(edad <= 0){
                System.out.println("Edad invalida");
                return;
            }

            if(tipo == 1){
                System.out.print("Carrera: ");
                String carrera = sc.nextLine().trim();

                if(carrera.isEmpty()){
                    System.out.println("Campo obligatorio");
                    return;
                }
                personas.add(new Estudiante(cedula,nombre,edad,carrera));
            }else if(tipo == 2){
                System.out.print("Asignatura: ");
                String asignatura = sc.nextLine().trim();
                if(asignatura.isEmpty()){
                    System.out.println("Campo obligatorio");
                    return;
                }
                personas.add(new Docente(cedula,nombre,edad,asignatura));
            }else{
                System.out.println("Tipo invalido");
                return;
            }
            System.out.println("Registro agregado correctamente");
        }catch(NumberFormatException e){
            System.out.println("Error: debe ingresar solo numeros");
        }
    }
    public static void mostrar(){
        if(personas.isEmpty()){
            System.out.println("No existen registros");
            return;
        }
        for(int i=0; i<personas.size(); i++){
            System.out.println("\nRegistro " + i);
            System.out.println(personas.get(i).mostrarDatos());

        }
    }
    public static void actualizar(){
        mostrar();
        try{
            System.out.print("Ingrese posicion: ");
            int pos = Integer.parseInt(sc.nextLine());

            if(pos < 0 || pos >= personas.size()){
                System.out.println("Registro no encontrado");
                return;
            }
            Persona persona = personas.get(pos);
            System.out.print("Nuevo nombre: ");
            String nombre = sc.nextLine().trim();

            if(nombre.isEmpty()){
                System.out.println("Campo obligatorio");
                return;
            }
            persona.setNombreCompleto(nombre);
            System.out.print("Nueva edad: ");
            int edad = Integer.parseInt(sc.nextLine());
            persona.setEdad(edad);
            System.out.println("Registro actualizado");
        }catch(NumberFormatException e){
            System.out.println("Debe ingresar solo numeros");
        }
    }

    public static void eliminar(){
        mostrar();
        try{
            System.out.print("Posicion a eliminar: ");
            int pos = Integer.parseInt(sc.nextLine());
            if(pos < 0 ||
                    pos >= personas.size()){
                System.out.println("Registro no encontrado");
                return;
            }
            personas.remove(pos);
            System.out.println("Registro eliminado");
        }catch(NumberFormatException e){
            System.out.println("Debe ingresar solo numeros");
        }
    }
}