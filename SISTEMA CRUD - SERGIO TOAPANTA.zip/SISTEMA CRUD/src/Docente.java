public class Docente extends Persona{
    private String asignatura;

    public Docente(String cedula,String nombreCompleto,int edad,String asignatura){
        super(cedula, nombreCompleto, edad);
        this.asignatura = asignatura;
    }

    public void setAsignatura(String asignatura){
        this.asignatura = asignatura;
    }

    public String asignatura(){
        return asignatura;
    }

    @Override
    public String mostrarDatos(){
        return super.mostrarDatos() + "\nTipo: Docente " + "\nAsignatura: " + asignatura;
    }
}
