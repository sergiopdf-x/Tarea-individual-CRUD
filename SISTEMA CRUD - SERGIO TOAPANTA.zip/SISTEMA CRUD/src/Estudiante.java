public class Estudiante extends Persona{
    private String carrera;

    public Estudiante(String cedula,String nombreCompleto,int edad, String carrera){
        super(cedula, nombreCompleto, edad);
        this.carrera = carrera;
    }

    public void setCarrera(String carrera){
        this.carrera = carrera;
    }

    public String getCarrera(){
        return carrera;
    }

    @Override
    public String mostrarDatos(){
        return super.mostrarDatos() + "\nTipo: Estudiante: " + "\nCarrera: " + carrera;
    }
}