public class Persona {
    protected String cedula;
    protected String nombreCompleto;
    protected int edad;

    public Persona(String cedula, String nombreCompleto, int edad) {
        this.cedula = cedula;
        this.nombreCompleto = nombreCompleto;
        this.edad = edad;
    }

    public String getCedula(){
        return cedula;
    }

    public String getNombreCompleto(){
        return nombreCompleto;
    }

    public int getEdad(){
        return edad;
    }

    public void setNombreCompleto(String nombreCompleto){
        this.nombreCompleto = nombreCompleto;
    }

    public void setEdad(int edad){
        this.edad = edad;
    }

    public String mostrarDatos(){
        return "Cedula: " + cedula + "\nNombre: " + nombreCompleto +
                "\nEdad: " + edad;
    }
}